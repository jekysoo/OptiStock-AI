import streamlit as st

st.set_page_config(page_title="Enterprise Inventory AI", page_icon="📦", layout="wide")

st.title("📦 Smart Supply Chain & Inventory AI Platform")
st.markdown("### Intelligent B2B Inventory Management System")
st.markdown("Welcome to the control panel. Please **select the required analytical module from the left menu 👈**")

st.info("💡 Developed for Master's Dissertation. The system is securely connected to the SQLite database.")

st.markdown("""
**Available Modules:**
* 📊 **1. Financial Audit:** Analysis of dead stock and frozen capital.
* 🤖 **2. AI Forecast:** Predictive demand forecasting (Prophet + XGBoost).
* 💎 **3. Advanced Analytics:** Explainable AI (SHAP) and ROI Simulator.
* 🏢 **4. Supplier Analytics:** Inbound cash flow and supplier ABC-analysis.
* ✉️ **5. Procurement Alerts:** Global Master Schedule Excel generation & Emailing.
""")
